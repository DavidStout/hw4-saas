module MoviesHelper
  # Checks if a number is odd:
end
